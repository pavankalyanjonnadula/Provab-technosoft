//
//  ViewController.swift
//  ClaritazAssignment
//
//  Created by Pavan Kalyan Jonnadula on 11/09/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit

class ViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

