//
//  ApiUrls.swift
//
//
//  Created by Pavan Kalyan Jonnadula on 12/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import Foundation

class ApiUrls{
    public static let articlesURL = "https://dev-api.vajro.com/fetch_shopify_article?appid=14382&blog_handle=news"
}
