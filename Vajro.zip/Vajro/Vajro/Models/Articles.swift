//
//  Articles.swift
//
//  Created on June 12, 2020
//
import Foundation

struct Articles: Codable {

	let id: Int
	let title: String
	let createdAt: String
	let bodyHtml: String
	let blogId: Int
	let author: String
	let userId: Int
	let publishedAt: String
	let updatedAt: String
	let summaryHtml: String
	let templateSuffix: String
	let handle: String
	let tags: String
	let adminGraphqlApiId: String
	let image: Image

	private enum CodingKeys: String, CodingKey {
		case id = "id"
		case title = "title"
		case createdAt = "created_at"
		case bodyHtml = "body_html"
		case blogId = "blog_id"
		case author = "author"
		case userId = "user_id"
		case publishedAt = "published_at"
		case updatedAt = "updated_at"
		case summaryHtml = "summary_html"
		case templateSuffix = "template_suffix"
		case handle = "handle"
		case tags = "tags"
		case adminGraphqlApiId = "admin_graphql_api_id"
		case image = "image"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		id = try values.decode(Int.self, forKey: .id)
		title = try values.decode(String.self, forKey: .title)
		createdAt = try values.decode(String.self, forKey: .createdAt)
		bodyHtml = try values.decode(String.self, forKey: .bodyHtml)
		blogId = try values.decode(Int.self, forKey: .blogId)
		author = try values.decode(String.self, forKey: .author)
		userId = try values.decode(Int.self, forKey: .userId)
		publishedAt = try values.decode(String.self, forKey: .publishedAt)
		updatedAt = try values.decode(String.self, forKey: .updatedAt)
		summaryHtml = try values.decode(String.self, forKey: .summaryHtml)
		templateSuffix = "" // TODO: Add code for decoding `templateSuffix`, It was null at the time of model creation.
		handle = try values.decode(String.self, forKey: .handle)
		tags = try values.decode(String.self, forKey: .tags)
		adminGraphqlApiId = try values.decode(String.self, forKey: .adminGraphqlApiId)
		image = try values.decode(Image.self, forKey: .image)
	}

}
