//
//  Image.swift
//
//  Created on June 12, 2020
//
import Foundation

struct Image: Codable {

	let createdAt: String
	let alt: String
	let width: Int
	let height: Int
	let src: String

	private enum CodingKeys: String, CodingKey {
		case createdAt = "created_at"
		case alt = "alt"
		case width = "width"
		case height = "height"
		case src = "src"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		createdAt = try values.decode(String.self, forKey: .createdAt)
		alt = try values.decode(String.self, forKey: .alt)
		width = try values.decode(Int.self, forKey: .width)
		height = try values.decode(Int.self, forKey: .height)
		src = try values.decode(String.self, forKey: .src)
	}

}
