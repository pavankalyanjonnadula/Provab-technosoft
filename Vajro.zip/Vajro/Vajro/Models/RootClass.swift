//
//  RootClass.swift
//
//  Created on June 12, 2020
//
import Foundation

struct RootClass: Codable {

	let articles: [Articles]
	let status: String

	private enum CodingKeys: String, CodingKey {
		case articles = "articles"
		case status = "status"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		articles = try values.decode([Articles].self, forKey: .articles)
		status = try values.decode(String.self, forKey: .status)
	}

}
