//
//  ArticlesViewModel.swift
//  Vajro
//
//  Created by Pavan Kalyan Jonnadula on 12/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import Foundation


class ArticlesViewModel {
    
    private var articles:[Articles] = [Articles]()
    private var cellViewModels:[ArticleCellViewModel] = [ArticleCellViewModel]() {
        didSet {
            self.reloadTableViewClosure?()
        }
    }
    var numberOfCells: Int {
        return cellViewModels.count
    }
    var reloadTableViewClosure: (()->())?
   
    func getAllArticLes(){
        WebService.shared.getRequest(urlString: ApiUrls.articlesURL) { (json, response, error) in
            let decoder = JSONDecoder()
            do {
                let mainModel = try decoder.decode(RootClass.self, from: json ?? Data())
                self.articles = mainModel.articles
                self.processFetchedArticles()
                
            }  catch {
                print("error: ", error.localizedDescription)
            }
        }
    }
    
    func processFetchedArticles(){
        cellViewModels = self.articles.compactMap({ (article) in
            let caluactedHeight = (Int(ScreenSize.SCREEN_WIDTH) * article.image.height)/article.image.width
            return ArticleCellViewModel(imageUrlString: article.image.src, title: article.title, htmlDescription: article.summaryHtml, heightOfImage: article.image.height, widthOfImage: article.image.width,bodyHtml: article.bodyHtml,aspectHeightOfImage: caluactedHeight)
        })
        
    }
    func getCellViewModel( at indexPath: IndexPath ) -> ArticleCellViewModel {
        return cellViewModels[indexPath.row]
    }
    
    
}


class ArticleCellViewModel {
    let imageUrlString : String
    let title : String
    let htmlDescription : String
    let heightOfImage : Int
    let widthOfImage : Int
    let bodyHtml : String
    let aspectHeightOfImage : Int
    init(imageUrlString : String,title : String,htmlDescription : String,heightOfImage : Int,widthOfImage : Int,bodyHtml : String,aspectHeightOfImage : Int) {
        self.imageUrlString = imageUrlString
        self.title = title
        self.htmlDescription = htmlDescription
        self.heightOfImage = heightOfImage
        self.widthOfImage = widthOfImage
        self.bodyHtml = bodyHtml
        self.aspectHeightOfImage = aspectHeightOfImage
    }
}
