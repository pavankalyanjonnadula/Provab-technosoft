//
//  ArticlesTableViewCell.swift
//  Vajro
//
//  Created by Pavan Kalyan Jonnadula on 12/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit
import SDWebImage

class ArticlesTableViewCell: UITableViewCell {

    @IBOutlet weak var articleImage: UIImageView!
    @IBOutlet weak var summaryLabel: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var heightOfImageView: NSLayoutConstraint!
       
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }

}
