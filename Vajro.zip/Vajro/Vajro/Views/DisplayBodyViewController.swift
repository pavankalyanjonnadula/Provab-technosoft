//
//  DisplayBodyViewController.swift
//  Vajro
//
//  Created by Pavan Kalyan Jonnadula on 12/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit
import WebKit
class DisplayBodyViewController: UIViewController {
    @IBOutlet weak var bodyWebView: WKWebView!
    
    var bodyHtml = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        let headerString = "<header><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'></header>"

        bodyWebView.loadHTMLString(headerString + bodyHtml, baseURL: nil)

    }


}
