//
//  ViewController.swift
//  Vajro
//
//  Created by Pavan Kalyan Jonnadula on 12/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var articlesTableView: UITableView!
    
    lazy var viewModel: ArticlesViewModel = {
        return ArticlesViewModel()
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeViewModel()
        articlesTableView.estimatedRowHeight = 100
        articlesTableView.rowHeight = UITableView.automaticDimension
    }
    func initializeViewModel(){
        SKProgressView.shared.showProgressView(self.view)
        viewModel.getAllArticLes()
        viewModel.reloadTableViewClosure = { [weak self] () in
            SKProgressView.shared.hideProgressView()
            DispatchQueue.main.async {
                self?.articlesTableView.delegate = self
                self?.articlesTableView.dataSource = self
                self?.articlesTableView.reloadData()
            }
        }
    }
  
}

extension ViewController : UITableViewDelegate , UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let articelCell = tableView.dequeueReusableCell(withIdentifier: "article") as! ArticlesTableViewCell
        let iteratorViewModel = viewModel.getCellViewModel(at: indexPath)
        articelCell.title.text = iteratorViewModel.title
        articelCell.summaryLabel.text = iteratorViewModel.htmlDescription
        articelCell.articleImage.sd_setImage(with: URL(string: iteratorViewModel.imageUrlString), completed: nil)
        articelCell.heightOfImageView.constant = CGFloat(iteratorViewModel.aspectHeightOfImage)
        return articelCell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfCells
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let displayVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "DisplayBodyViewController") as! DisplayBodyViewController
        let iteratorViewModel = viewModel.getCellViewModel(at: indexPath)
        displayVC.bodyHtml = iteratorViewModel.bodyHtml
        self.navigationController?.pushViewController(displayVC, animated: true)
    }
}
