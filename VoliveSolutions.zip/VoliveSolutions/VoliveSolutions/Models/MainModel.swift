//
//  MainModel.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on June 13, 2020
//
import Foundation

struct MainModel: Codable {

	let status: Int
	let count: Int
	let serviceTermsConditions: [ServiceTermsConditions]

	private enum CodingKeys: String, CodingKey {
		case status = "status"
		case count = "count"
		case serviceTermsConditions = "service_terms_conditions"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		status = try values.decode(Int.self, forKey: .status)
		count = try values.decode(Int.self, forKey: .count)
		serviceTermsConditions = try values.decode([ServiceTermsConditions].self, forKey: .serviceTermsConditions)
	}

}