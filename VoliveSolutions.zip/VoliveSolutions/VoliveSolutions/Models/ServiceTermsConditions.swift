//
//  ServiceTermsConditions.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on June 13, 2020
//
import Foundation

struct ServiceTermsConditions: Codable {

	let appointmentSubservicesId: String
	let appointmentSubservicesName: String
	let termsConditions: [TermsConditions]

	private enum CodingKeys: String, CodingKey {
		case appointmentSubservicesId = "appointment_subservices_id"
		case appointmentSubservicesName = "appointment_subservices_name"
		case termsConditions = "terms_conditions"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		appointmentSubservicesId = try values.decode(String.self, forKey: .appointmentSubservicesId)
		appointmentSubservicesName = try values.decode(String.self, forKey: .appointmentSubservicesName)
		termsConditions = try values.decode([TermsConditions].self, forKey: .termsConditions)
	}

}