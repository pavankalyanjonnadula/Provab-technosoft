//
//  TermsConditions.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on June 13, 2020
//
import Foundation

struct TermsConditions: Codable {

	let termsConditions: String

	private enum CodingKeys: String, CodingKey {
		case termsConditions = "terms_conditions"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		termsConditions = try values.decode(String.self, forKey: .termsConditions)
	}

}