//
//  TermsAndConditionsViewModel.swift
//  VoliveSolutions
//
//  Created by Pavan Kalyan Jonnadula on 13/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import Foundation

class TermsAndConditionsViewModel{
    private var terms:[TermsConditions] = [TermsConditions]()
    var cellViewModels:[ConditionsViewModel] = [ConditionsViewModel]() {
           didSet {
               self.reloadTableViewClosure?()
           }
       }
       var numberOfCells: Int {
           return cellViewModels.count
       }
       var reloadTableViewClosure: (()->())?
    
    
    
    func getDataFromServer(){
        WebService.shared.getRequest(urlString: "https://demomaplebrains.ca/usva/api/services/waiverForms?appointment_services_id=1") { (json, response, error) in
            let decoder = JSONDecoder()
            do {
                let mainModel = try decoder.decode(MainModel.self, from: json ?? Data())
                self.terms = mainModel.serviceTermsConditions[0].termsConditions
                self.processFetchedTserms()
                
            }  catch {
                print("error: ", error.localizedDescription)
            }
        }
    }
    
    func processFetchedTserms(){
        cellViewModels = self.terms.compactMap({ (condition) in
            return ConditionsViewModel(condition: condition.termsConditions, isSelected: false)
        })
    }
    func getCellViewModel(index: Int) -> ConditionsViewModel {
          return cellViewModels[index]
      }
    
}

class ConditionsViewModel{
    let condition : String
    var isSelected : Bool
    
    init(condition : String , isSelected : Bool) {
        self.condition = condition
        self.isSelected = isSelected
    }
}
