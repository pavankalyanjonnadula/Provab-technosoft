//
//  CheckBoxTableViewCell.swift
//  VoliveSolutions
//
//  Created by Pavan Kalyan Jonnadula on 13/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit

class CheckBoxTableViewCell: UITableViewCell {

    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var checkBoxBtn: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
