//
//  ViewController.swift
//  VoliveSolutions
//
//  Created by Pavan Kalyan Jonnadula on 13/06/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK: Outlets
    @IBOutlet weak var termsTableView: UITableView!
    @IBOutlet weak var agreeBtn: UIButton!
    @IBOutlet weak var tintBgView: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var termsAndConditiondLabel: UILabel!
    @IBOutlet weak var proceedBtn: UIButton!
    
    
    //MARK: Properties
    lazy var mainViewModel: TermsAndConditionsViewModel = {
        return TermsAndConditionsViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeViewModel()
        initializeView()
    }
    func initializeView(){
        let attributedString = NSMutableAttributedString.init(string: "Terms and Conditions")
        attributedString.addAttribute(NSAttributedString.Key.underlineStyle, value: 1, range:
            NSRange.init(location: 0, length: attributedString.length));
        termsAndConditiondLabel.attributedText = attributedString
        
    }
    func initializeViewModel(){
         SKProgressView.shared.showProgressView(self.view)
         mainViewModel.getDataFromServer()
         mainViewModel.reloadTableViewClosure = { [weak self] () in
             SKProgressView.shared.hideProgressView()
             DispatchQueue.main.async {
                 self?.termsTableView.delegate = self
                 self?.termsTableView.dataSource = self
                 self?.termsTableView.reloadData()
             }
         }
     }
    //MARK: Button Actions
    @IBAction func cancelBtnAction(_ sender: Any) {
        mainView.isHidden = true
        tintBgView.isHidden = true
    }
    
    @IBAction func agreeTermsAndConditionsBtn(_ sender: UIButton) {
        if sender.backgroundColor == UIColor.clear{
            sender.backgroundColor = UIColor.darkGray
            sender.setImage(nil, for: .normal)
        }else{
            sender.backgroundColor = UIColor.clear
            sender.setImage(UIImage(systemName: "checkmark.square.fill"), for: .normal)
        }
    }
    @IBAction func clickHereToProceddAction(_ sender: Any) {
        mainView.isHidden = false
        tintBgView.isHidden = false
    }
    @IBAction func proceedBtnAction(_ sender: Any) {
        let allModels = mainViewModel.cellViewModels
        for model in allModels{
            if model.isSelected == false{
                showAlert(title: "Error", message: "Check all terms to proceed")
                return
            }
        }
        if agreeBtn.backgroundColor == UIColor.clear{
            showAlert(title: "Sucess", message: "Sucessfully accepted terms and conditions")
        }else{
            showAlert(title: "Error", message: "Check all terms to proceed")
            return
        }
    }
 
    
}

extension ViewController : UITableViewDelegate , UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        mainViewModel.numberOfCells
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "term") as! CheckBoxTableViewCell
        let iteratorModel = mainViewModel.getCellViewModel(index: indexPath.row)
        cell.conditionLabel.text = iteratorModel.condition
        cell.checkBoxBtn.tag = indexPath.row
        if iteratorModel.isSelected{
            cell.checkBoxBtn.setImage(UIImage(systemName: "checkmark.square.fill"), for: .normal)
        }
        else{
            cell.checkBoxBtn.backgroundColor = UIColor.darkGray
            cell.checkBoxBtn.setImage(nil, for: .normal)
        }
        return cell
    }
    
    @IBAction func checkBoxAction(_ sender: UIButton) {
        print("the btn tag",sender.tag)
        let model = mainViewModel.getCellViewModel(index: sender.tag)
        if model.isSelected == false{
            sender.backgroundColor = UIColor.clear
            
            sender.setImage(UIImage(systemName: "checkmark.square.fill"), for: .normal)
            model.isSelected = true
        }
        else{
            model.isSelected = false
            
            sender.backgroundColor = UIColor.darkGray
            sender.setImage(nil, for: .normal)
        }
    }
}
